//
//  Movie.swift
//  TableView
//
//  Created by Macbook on 2022-08-07.
//

import Foundation
class Movie {
    var title: String
    var description: String
    init (title: String, description: String){
        self.title = title
        self.description = description
    }
    
}
